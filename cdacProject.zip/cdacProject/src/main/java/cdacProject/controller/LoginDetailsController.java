package cdacProject.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;


import javax.servlet.http.HttpSession;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDDocumentInformation;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.interactive.digitalsignature.PDSignature;
import org.apache.pdfbox.pdmodel.interactive.digitalsignature.visible.PDVisibleSigProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import cdacProject.model.LoginUser;
import cdacProject.service.LoginDetailsService;


@Controller
public class LoginDetailsController 
{
   @Autowired
   private LoginDetailsService loginDetailsService;
   
   
   @RequestMapping(path="/register",method=RequestMethod.GET)
	public String  registerPage()
	{
		return "register";
	}
   
   
   
   @RequestMapping(path="/about",method=RequestMethod.GET)
	public String  aboutPage()
	{
		return "about";
	}
   
   @RequestMapping(path="/contactus",method=RequestMethod.GET)
  	public String  contact_usPage()
  	{
  		return "contact_us";
  	}
   
   
   @RequestMapping(path="/",method=RequestMethod.GET)
  	public String  DefaultPage()
  	{
  		return "Dashboard";
  	}
   
   @RequestMapping(path="/login",method=RequestMethod.GET)
 	public String  LoginPage()
 	{
 		return "login";
 	}
   
   
   @RequestMapping(path="/forgotpass",method=RequestMethod.GET)
 	public String  ForgotPage()
 	{
 		return "forgot_pass";
 	}
   
   
   @RequestMapping(path="/UploadPage",method=RequestMethod.GET)
	public String  UploadPage()
	{
		return "UploadPage";
	}
   
 //Using ModelAttribute
 		@RequestMapping(path="/login",method=RequestMethod.POST)
 		public String RegisterHandler(@ModelAttribute LoginUser data)
 		{
 	       
 			System.out.println(data); 
 			
 			loginDetailsService.insertUser(data);
 	        
 			return "login";
 		}
   
 		@RequestMapping(path="/upload",method=RequestMethod.POST)
 		public String LoginHandler(@RequestParam("userid") int uid, @RequestParam("password") String pswd )
 		{
 			LoginUser obj= loginDetailsService.getUserObj(uid);
 			 
 			 if(obj==null)
 			 {
 				return  "errorPageUserNotFound";
 			 }
 			
 			 else
 			 {
 				 if(obj.getPassword().equals(pswd))
 				 {
 					 return "UploadPage";
 				 }
 				 
 				 else
 				 {
 					 return "errorPagePassIncorrect"; 
 				 } 
 			 }
 		}
 		
 	
 		@RequestMapping(path="/changePass",method=RequestMethod.POST)
 		public String FogotPassHandler(@RequestParam("userid") int uid, @RequestParam("password") String pswd)
 		{
 			
 			LoginUser userObj = loginDetailsService.getUserObj(uid);
 			if(userObj!=null)
 			{	
 			
 			 LoginUser obj= new LoginUser();
 			 obj.setUserid(uid);
 			 obj.setPassword(pswd);
 			 obj.setName(userObj.getName());
 			 obj.setEmailid(userObj.getEmailid());
 			
 			 loginDetailsService.passUpdate(obj);
 	        
 			 return "login";
 			}
 			
 			else 
 				return "errorPageUserNotFound";
 		    }
 		
 	
 		@RequestMapping(path="/success", method = RequestMethod.POST)
 		public String FileUploadHandler(@RequestParam("E-Mail") String toEmail ,HttpSession s, Model m )
 		{
 			System.out.println("File upload Handler ");
 			/*System.out.println(file.getName());
 			System.out.println(file.getStorageDescription());
 			System.out.println(file.getContentType());*/
 			
 			//getting the byte data of file
 			//byte[] bytes = file.getBytes();
 			
 			//Saving file to server...
 			
 			//String path = s.getServletContext().getRealPath("/")+"WEB-INF"+File.separator+"resources"+File.separator+"img"+ File.separator+file.getOriginalFilename();
 			//System.out.println(path);
 			
 			String path="C:/Users/hp/OneDrive/Desktop/temp.pdf";
 			
 			
 			//Used to save the file into specified location 
 		/*	try 
 			{
			  FileOutputStream fos= new FileOutputStream(path);
			  fos.write(bytes);
			  fos.close();
			  System.out.println("File Uploaded");
			}
 			
 			catch (Exception e) 
 			{
				e.printStackTrace();
				System.out.println("Uploading error");
			}*/
 			
 			
 		    String msg = "Hello , Dear , this is message for security for security check. ";
 	        String subject = "CodersArea : Confirmation";
 	        String to = toEmail;
 	        String from = "dharmeshdubey29101995@gmail.com";
 	     
 	       loginDetailsService.sendAttach(msg, subject, to, from, path);
 			
 	       m.addAttribute("senderMailid",to);
 			
 			return "success";
 		}
 		
 		
 		@RequestMapping(path="/signedData",method=RequestMethod.POST)
 		public String SignedHandler(@RequestParam("signature") String digiText, @RequestParam("userid") int id)
 		{
 			
 			   LoginUser obj= new LoginUser();
 	 		   LoginUser userObj = loginDetailsService.getUserObj(id);
 	 		   
 	 		   obj.setEmailid(userObj.getEmailid());
 	           obj.setName(userObj.getName());
 	           obj.setPassword(userObj.getPassword());
 	           obj.setUserid(userObj.getUserid());
 			
 			 System.out.println("Enter in EncrypttoDecrypt class-------------------------------");
             //Creating a Signature object
             System.out.println("Creating a Signature object");
             try {
                 Signature sign = Signature.getInstance("SHA256withRSA");
                 System.out.println("sign"+sign);
             } catch (NoSuchAlgorithmException e) {
                 throw new RuntimeException(e);
             }

             //Creating KeyPair generator object
             System.out.println("Creating KeyPair generator object using RSA");
             KeyPairGenerator keyPairGen = null;
             try {
                 keyPairGen = KeyPairGenerator.getInstance("RSA");
                 System.out.println("keyPairGen: "+keyPairGen);
             } catch (NoSuchAlgorithmException e) {
                 throw new RuntimeException(e);
             }

             //Initializing the key pair generator
             System.out.println("Initializing the key pair generator");
             keyPairGen.initialize(2048);

             //Generate the pair of keys
             System.out.println("Generate the pair of keys");
             KeyPair pair = keyPairGen.generateKeyPair();
             System.out.println("pair: "+pair);
             
             //-------------------------------------------------------------------------------------------------------------
             
             String path1 = String.format("C:/Users/hp/Eclipse-Workspace2/cdacProject/FilePublicPrivate/%sObjSerialize.txt", "publicKey");
             String path2 = String.format("C:/Users/hp/Eclipse-Workspace2/cdacProject/FilePublicPrivate/%sObjSerialize.txt", "privateKey");
            
     		File file1 = new File(path1);
     		File file2 = new File(path2);
     		
     		try {
     			FileOutputStream fileOutputStream1 = new FileOutputStream(file1);
     			ObjectOutputStream objectOutputStream1 = new ObjectOutputStream(fileOutputStream1);
     			objectOutputStream1.writeObject(pair.getPublic()); 
     			
     			objectOutputStream1.close();
     			
     			
     			FileOutputStream fileOutputStream2 = new FileOutputStream(file2);
     			ObjectOutputStream objectOutputStream2 = new ObjectOutputStream(fileOutputStream2);
     			objectOutputStream2.writeObject(pair.getPrivate());
  
     			objectOutputStream2.close();
     			
     			//fileOutputStream1.close();
     			//fileOutputStream2.close();
     			
     		} catch (FileNotFoundException e) {
     			System.out.println("FileNotFoundException" + e.getMessage());
     			e.printStackTrace();
     		} catch (IOException e) {
     			System.out.println("IOException" + e.getMessage());
     			e.printStackTrace();
     		}
            
     		//------------------------------------------------------------------------------------
             
     		
     		try {
    			
         		File file3 = new File(path1);
         		File file4 = new File(path2); 
    			
    			FileInputStream fileInputStreamObj1 = new FileInputStream(path1);
    			ObjectInputStream objectInputStreamObj1 = new ObjectInputStream(fileInputStreamObj1);
    			PublicKey publicKeyObj = (PublicKey)objectInputStreamObj1.readObject();
    			objectInputStreamObj1.close();
    			//fileInputStreamObj1.close();
    			
    			FileInputStream fileInputStreamObj2 = new FileInputStream(path2);
    			ObjectInputStream objectInputStreamObj2 = new ObjectInputStream(fileInputStreamObj2);
    			PrivateKey	privateKeyObj = (PrivateKey)objectInputStreamObj2.readObject();
    			objectInputStreamObj2.close();
    			//fileInputStreamObj2.close();
    	
    			//fileInputStreamObj1.close();
    			//fileInputStreamObj2.close();
    			
    			//objectInputStreamObj1.close();
    			
    			System.out.println("-------------------------------------------");
    			System.out.println("Public--------------> "+publicKeyObj);
    			System.out.println("Private--------------> "+privateKeyObj);
    			System.out.println("-------------------------------------------");
    			
    			
    		} catch (FileNotFoundException e) {
    			e.printStackTrace();
    		} catch (IOException e) {
    			e.printStackTrace();
    		} catch (ClassNotFoundException e) {
    			e.printStackTrace();
    		}
             
             
             //-------------------------------------------------------------------------------------------------------------

             //Getting the public key from the key pair
             System.out.println("Getting the public key from the key pair");
             PublicKey publicKey = pair.getPublic();
             System.out.println("publicKey: "+publicKey);
 			 
            // String stringPublic = publicKey.toString();
             obj.setPublic_key(publicKey);
             
             
             System.out.println("Inside CreatingDigitalSignature class------------------------------");

             System.out.println("Getting the private key from the key pair");
             PrivateKey privKey = pair.getPrivate();
             System.out.println("privKey: "+privKey);
             
             
            // String stringPriv = privKey.toString();
             obj.setPrivate_key(privKey);

             
             //Creating a Signature object
             System.out.println("Creating a Signature object");
             Signature sign = null;
             try {
                 sign = Signature.getInstance("SHA256withRSA");
                 System.out.println("sign: "+sign);
             } catch (NoSuchAlgorithmException e1) {
                 throw new RuntimeException(e1);
             }

             //Initialize the signature
             System.out.println("Initialize the signature using privKey code is sign.initSign(privKey) ");
             try {
                 sign.initSign(privKey);
             } catch (InvalidKeyException e2) {
                 throw new RuntimeException(e2);
             }

            // System.out.println("Enter some text which goes in bytes as Signature: ");
             //String str1=s.nextLine(); 
             byte[] bytes = digiText.getBytes(); //bytes: [B@567d299b
             System.out.println("bytes: "+bytes); //bytes: [B@567d299b

             //Adding data to the signature
             System.out.println("Adding data to the signature using sign.update(bytes)--- ");
             try {
                 sign.update(bytes);
                 System.out.println("sign: "+sign); //
             } catch (SignatureException e3) {
                 throw new RuntimeException(e3);
             }

             //Calculating the signature
             System.out.println("Calculating the signature");
             byte[] signature = new byte[0];
             try {
            	 signature = sign.sign();
                 System.out.println("byt: "+signature);  //byt: [B@2eafffde
             } catch (SignatureException e4) {
                 throw new RuntimeException(e4);
             }

             //Printing the signature
             System.out.println("Printing the signature");
             try {
                 System.out.println("Digital signature for given text: "+new String(signature, "UTF8"));
             } catch (UnsupportedEncodingException e5) {
                 throw new RuntimeException(e5);
             }

 			
 		    //String publicKey = loginDetailsService.EncrypDecrypt(text);
 		    //String privateKey = loginDetailsService.CreatingDigitalSign(digiText);
 		   
 		 /* LoginUser obj= new LoginUser();
 		   LoginUser userObj = loginDetailsService.getUserObj(id);*/
 		   
 		  
           //obj.setPublic_key(publicKey);
           //obj.setPrivate_key(privateKey);
 		   
             obj.setSign_text(digiText);
             
 		   loginDetailsService.passUpdate(obj);
 		   
 		   LoginUser userObj2 = loginDetailsService.getUserObj(id);
 		  /* String private_key = userObj.getPrivate_key();
 		   String public_key = userObj.getPublic_key();
 		   
 		   PrivateKey obj1= (PrivateKey)private_key;
 		   PublicKey obj2= (PublicKey)public_key;*/
 		   
 		   System.out.println(userObj.getName());
 		   //System.out.println(userObj.getPublic_key());
 		   //System.out.println(userObj.getPrivate_key());
 		   
 		   
 		  System.out.println("____________________________________________________________________________________________");
 		   
 		 /* String path3 = String.format("C:/Users/User/workspace AJ/cdacProject/FilePublicPrivate/%sObjSerialize.txt", "publicKey");
 		 String path4 = String.format("C:/Users/User/workspace AJ/cdacProject/FilePublicPrivate/%sObjSerialize.txt", "privateKey");
 			File file3 = new File(path3);
 			try {
 				file3.createNewFile();
 			} catch (IOException e) {
 				System.out.println("IOException" + e.getMessage());
 				e.printStackTrace();
 			}
 			
 			try {
 				FileOutputStream fileOutputStream = new FileOutputStream(file3);
 				ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
 				objectOutputStream.writeObject(publicKey); 
 				objectOutputStream.close();
 				
 			} catch (FileNotFoundException e) {
 				System.out.println("FileNotFoundException" + e.getMessage());
 				e.printStackTrace();
 			} catch (IOException e) {
 				System.out.println("IOException" + e.getMessage());
 				e.printStackTrace();
 			}
 			
 			return file;   */
 		   
 		  System.out.println("__________________________________________________________________________________________________");
 	
 		  
 		  
 		 System.out.println("__________________________________________________________________________________________________");
 		   
 		
 		     return "verificationPage";
  		   
  	  		}
 		
 		
 		
 		@RequestMapping(path="/verification",method=RequestMethod.POST)
 		public String VerifyHandler(@RequestParam("verificationText") String veriText, @RequestParam("userid") int id)
 		{
 		   
    		String path1 = String.format("C:/Users/hp/Eclipse-Workspace2/cdacProject/FilePublicPrivate/%sObjSerialize.txt", "publicKey");
            String path2 = String.format("C:/Users/hp/Eclipse-Workspace2/cdacProject/FilePublicPrivate/%sObjSerialize.txt", "privateKey");
           /* File file1 = new File(path1);
    		File file2 = new File(path2);*/
            
            boolean flag=false;
     		
     		try {
    			
    			
    			FileInputStream fileInputStreamObj1 = new FileInputStream(path1);
    			ObjectInputStream objectInputStreamObj1 = new ObjectInputStream(fileInputStreamObj1);
    			PublicKey publicKeyObj = (PublicKey)objectInputStreamObj1.readObject();
    			objectInputStreamObj1.close();
    			//fileInputStreamObj1.close();
    			
    			FileInputStream fileInputStreamObj2 = new FileInputStream(path2);
    			ObjectInputStream objectInputStreamObj2 = new ObjectInputStream(fileInputStreamObj2);
    			PrivateKey	privateKeyObj = (PrivateKey)objectInputStreamObj2.readObject();
    			objectInputStreamObj2.close();
    			//fileInputStreamObj2.close();
    	
    			//fileInputStreamObj1.close();
    			//fileInputStreamObj2.close();
    			
    			//objectInputStreamObj1.close();
    			
    			System.out.println("-------------------------------------------");
    			System.out.println("Public--------------> "+publicKeyObj);
    			System.out.println("Private--------------> "+privateKeyObj);
    			System.out.println("-------------------------------------------");
    			
    			
    	
             
             //-------------------------------------------------------------------------------------------------------------

    		
    		
     		 //Creating a Signature object
            System.out.println("Creating a Signature object");
            Signature sign = null;
            try {
                sign = Signature.getInstance("SHA256withRSA");
                System.out.println("sign: "+sign);
            } catch (NoSuchAlgorithmException e1) {
                throw new RuntimeException(e1);
            }

            //Initialize the signature
            System.out.println("Initialize the signature using privKey code is sign.initSign(privKey) ");
            try {
                sign.initSign(privateKeyObj);
            } catch (InvalidKeyException e2) {
                throw new RuntimeException(e2);
            }

           // System.out.println("Enter some text which goes in bytes as Signature: ");
            //String str1=s.nextLine(); 
            
            LoginUser userObj = loginDetailsService.getUserObj(id);
            String sign_text = userObj.getSign_text();
            
            byte[] bytes = sign_text.getBytes(); //bytes: [B@567d299b
            System.out.println("bytes: "+bytes); //bytes: [B@567d299b

            //Adding data to the signature
            System.out.println("Adding data to the signature using sign.update(bytes)--- ");
            try {
                sign.update(bytes);
                System.out.println("sign: "+sign); //
            } catch (SignatureException e3) {
                throw new RuntimeException(e3);
            }

            //Calculating the signature
            System.out.println("Calculating the signature");
            byte[] signature = new byte[0];
            try {
           	 signature = sign.sign();
                System.out.println("byt: "+signature);  //byt: [B@2eafffde
            } catch (SignatureException e4) {
                throw new RuntimeException(e4);
            }

            //Printing the signature
            System.out.println("Printing the signature");
            try {
                System.out.println("Digital signature for given text: "+new String(signature, "UTF8"));
            } catch (UnsupportedEncodingException e5) {
                throw new RuntimeException(e5);
            }
     		
            
            String storedSignatureObj = new String(signature, "UTF8");
            
            
            
            //signature verification code
            
            
            
            //Creating a Signature object
            System.out.println("Creating a Signature object");
            Signature signVerify = null;
            try {
            	signVerify = Signature.getInstance("SHA256withRSA");
                System.out.println("signVerify: "+signVerify);
            } catch (NoSuchAlgorithmException e1) {
                throw new RuntimeException(e1);
            }

            //Initialize the signature
            System.out.println("Initialize the signature using privKey code is sign.initSign(privKey) ");
            try {
            	signVerify.initSign(privateKeyObj);
            } catch (InvalidKeyException e2) {
                throw new RuntimeException(e2);
            }

           // System.out.println("Enter some text which goes in bytes as Signature: ");
            //String str1=s.nextLine(); 
            
            
            byte[] bytes1 = veriText.getBytes(); //bytes: [B@567d299b
            System.out.println("bytes: "+bytes1); //bytes: [B@567d299b

            //Adding data to the signature
            System.out.println("Adding data to the signature using sign.update(bytes)--- ");
            try {
            	signVerify.update(bytes1);
                System.out.println("sign: "+signVerify); //
            } catch (SignatureException e3) {
                throw new RuntimeException(e3);
            }

            //Calculating the signature
            System.out.println("Calculating the signature");
            byte[] signatureVerify = new byte[0];
            try {
            	signatureVerify = signVerify.sign();
                System.out.println("byt: "+signatureVerify);  //byt: [B@2eafffde
            } catch (SignatureException e4) {
                throw new RuntimeException(e4);
            }

            //Printing the signature
            System.out.println("Printing the signature");
            try {
                System.out.println("Digital signature for given text: "+new String(signatureVerify, "UTF8"));
            } catch (UnsupportedEncodingException e5) {
                throw new RuntimeException(e5);
            }
     		
            
            String newSignature = new String(signatureVerify, "UTF8");
            
            
            
            if(storedSignatureObj.equals(newSignature))
            {
            	flag=true;
            }
            
            else
            {
            	flag=false;
             }
            
     		}
            
            
          catch (FileNotFoundException e) {
    			e.printStackTrace();
    		} catch (IOException e) {
    			e.printStackTrace();
    		} catch (ClassNotFoundException e) {
    			e.printStackTrace();
    		}
             
     		
     		
     		if(flag)
     		{
     			return "Upload";
     		}
     		
     		else
     		{
     			return "verificationErrorPage";
     		}
     	
 		}

 		
 		
 		
 		@RequestMapping(path="/uploadedPage",method=RequestMethod.POST)
 		public String uploadedPageHandler(@RequestParam("fileData") CommonsMultipartFile file,HttpSession s ,@RequestParam("name") String name, @RequestParam("location") String location,@RequestParam("userid") int id)
 		{
 		   
 			//getting the byte data of file
 			byte[] bytes = file.getBytes();
 			
 			//Saving file to server...
 			
 			String path = s.getServletContext().getRealPath("/")+"WEB-INF"+File.separator+"resources"+File.separator+"img"+ File.separator+file.getOriginalFilename();
 			System.out.println(path);
 			
 			//Used to save the file into specified location 
 			try 
 			{
			  FileOutputStream fos= new FileOutputStream(path);
			  fos.write(bytes);
			  fos.close();
			  System.out.println("File Uploaded");
			}
 			
 			catch (Exception e) 
 			{
				e.printStackTrace();
				System.out.println("Uploading error");
			}
 		  
 		//_________________________________________________________________________________
 		
 		
 		//digital signature
 			
 			/*try {
				
			
 			//adding a blank page to existing pdf
 			File oldfile=new File(path);
 			PDDocument doc=PDDocument.load(oldfile);
 			PDPage firstpage=new PDPage();
 			 //PDPage page = doc.getPage(0); 
 			doc.addPage( firstpage);
 			
 			PDDocumentInformation docinfo=doc.getDocumentInformation();
 			//details to PDF
 			docinfo.setAuthor("Mayank");
 			docinfo.setTitle("Digital Signing");
 			docinfo.setCreator("D MAD");
 			docinfo.setCreationDate(Calendar.getInstance());
 			

 			//adding text to PDF
 			PDPageContentStream contentstream=new PDPageContentStream(doc,firstpage );
 			contentstream.beginText();
 			contentstream.setFont(PDType1Font.TIMES_ROMAN, 19);
 			contentstream.setLeading(17.0f);
 			
 			contentstream.newLineAtOffset(25, firstpage.getTrimBox().getHeight()-25);
 			
 			System.out.println("Enter your location");
 			Scanner sc=new Scanner(System.in);
 			String loc=sc.nextLine();
 			
 			System.out.println("Enter your name");
 			String str1=sc.nextLine();
 			//Calendar cl=Calendar.getInstance();
 			
 			//date
 			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
 			   LocalDateTime now = LocalDateTime.now();
 			   System.out.println(now);
 			
 			contentstream.showText("DIGITALLY SIGNED BY: "+name);
 			contentstream.newLine();
 			contentstream.showText("Location: "+location);
 			contentstream.newLine();
 			contentstream.showText(""+now);;
 			contentstream.newLine();
 			
 			contentstream.endText();
 			contentstream.close();
 			
 		//	Prepare the Signature:
 			PDSignature signature = new PDSignature();
 			signature.setFilter(PDSignature.FILTER_ADOBE_PPKLITE); // Choose a filter
 			signature.setSubFilter(PDSignature.SUBFILTER_ADBE_PKCS7_DETACHED);
 			signature.setName(name);
 			signature.setLocation(location);
 			signature.setReason("Digital Signature");
 			


 			Calendar cal = Calendar.getInstance();
 			signature.setSignDate(cal);

 	       	doc.addSignature(signature);
 	       	
 	      
 			PDVisibleSigProperties visibleSignatureProperties = new PDVisibleSigProperties();
 			visibleSignatureProperties.signerName("John Doe").signerLocation("City, Country").signatureReason("Digital Signature");

 			

 		

 			doc.save("C:/Users/User/Desktop/temp.pdf");
 			System.out.println("PDF Created");
 			doc.close();
 			
 			}
 			
 			catch (Exception e) {
				// TODO: handle exception
			}*/
 			
 			
 			
 			try {
				//----------------------------------------------------------------
 				File inputFile = new File(path);
 	            PDDocument document = PDDocument.load(inputFile);
 	            

// 	            System.out.println("Enter your location");
// 	            String loc=sc.nextLine();
// 	            System.out.println("Enter your name");
// 	            String str1=sc.nextLine();

 	            
 	            for (PDPage page : document.getPages()) {
 	         
 	           // int pageNumber = 1; // Replace with the actual page number
// 	            PDPage page = document.getPage(pageNumber);
 	            PDPageContentStream contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, true, true);

 	            contentStream.beginText();
 	            contentStream.setFont(PDType1Font.HELVETICA_BOLD, 12);
 	            contentStream.setLeading(17.0f);
 	           contentStream.newLineAtOffset(50, 150);
 	            //contentStream.newLineAtOffset(25, page.getTrimBox().getHeight()-25);
 	           // contentStream.showText("Digital Signing");
 	            
 	          //  contentStream.newLineAtOffset(25, page.getTrimBox().getHeight()-25);
 	    		
 	            
 	           
 	    		//date
 	    		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
 	    		   LocalDateTime datenow = LocalDateTime.now();
 	    		   System.out.println(datenow);
 	    		
 	    		   contentStream.showText("DIGITALLY SIGNED BY: "+name);
 	    		   contentStream.newLine();
 	    		   contentStream.showText("Location: "+location);
 	    		   contentStream.newLine();
 	    		   contentStream.showText(""+datenow);;
 	    		   contentStream.newLine();
 	    		
 	            
 	    		
 	            contentStream.endText();


 	            contentStream.close();
 	            
 	           
 	            }
 	            
 	            document.save("C:/Users/hp/OneDrive/Desktop/temp.pdf");
 	            document.close();
 	            
 	            
 	            System.out.println("Text added successfully.");
 	        } 
 			
 			catch (IOException e) 
 			{
 	            e.printStackTrace();
 	        }
 			
 			
 			
 			LoginUser obj = new LoginUser();
 			LoginUser userObj = loginDetailsService.getUserObj(id);
 			
 			obj.setUserid(userObj.getUserid());
 			obj.setName(userObj.getName());
 			obj.setEmailid(userObj.getEmailid());
 			obj.setPassword(userObj.getPassword());
 			obj.setPublic_key(userObj.getPublic_key());
 			obj.setPrivate_key(userObj.getPrivate_key());
 			obj.setSign_text(name);
 			
 		    loginDetailsService.passUpdate(obj);
 			
 		  return "verificationPage";
 		
 		  
 		}
 		
 		
 		
 		
 		
 		
}
