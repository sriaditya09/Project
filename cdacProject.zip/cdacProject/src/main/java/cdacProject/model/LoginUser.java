package cdacProject.model;

import java.security.PrivateKey;
import java.security.PublicKey;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="LoginDetails")
public class LoginUser 
{

 @Id
 public int userid;
 
 public String name;
 
 public String emailid;
 
 public String password;
 
 public  PublicKey public_key;
 
 public PrivateKey private_key;
 
 public String sign_text;

public int getUserid() {
	return userid;
}

public void setUserid(int userid) {
	this.userid = userid;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getEmailid() {
	return emailid;
}

public void setEmailid(String emailid) {
	this.emailid = emailid;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public PublicKey getPublic_key() {
	return public_key;
}

public void setPublic_key(PublicKey public_key) {
	this.public_key = public_key;
}

public PrivateKey getPrivate_key() {
	return private_key;
}

public void setPrivate_key(PrivateKey private_key) {
	this.private_key = private_key;
}

public String getSign_text() {
	return sign_text;
}

public void setSign_text(String sign_text) {
	this.sign_text = sign_text;
}

public LoginUser(int userid, String name, String emailid, String password, PublicKey public_key, PrivateKey private_key,
		String sign_text) {
	super();
	this.userid = userid;
	this.name = name;
	this.emailid = emailid;
	this.password = password;
	this.public_key = public_key;
	this.private_key = private_key;
	this.sign_text = sign_text;
}

public LoginUser() {
	super();
	// TODO Auto-generated constructor stub
}

@Override
public String toString() {
	return "LoginUser [userid=" + userid + ", name=" + name + ", emailid=" + emailid + ", password=" + password
			+ ", public_key=" + public_key + ", private_key=" + private_key + ", sign_text=" + sign_text + "]";
}



 
 
 

}
