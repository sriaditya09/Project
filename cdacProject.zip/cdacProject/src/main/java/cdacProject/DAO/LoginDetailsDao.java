package cdacProject.DAO;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import cdacProject.model.LoginUser;

@Repository
public class LoginDetailsDao 
{
 
	@Autowired
	private HibernateTemplate hibernateTemplate;


	
	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}


	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}


	@Transactional 
	public int insert(LoginUser data)
	{
		Integer value =(Integer)hibernateTemplate.save(data);
		
		return value;
	}
	
	
		@Transactional 
	public LoginUser getByUser(int uid)
	{
		return this.hibernateTemplate.get(LoginUser.class, uid);
	}
	
	
	@Transactional 
	public void updatepass(LoginUser data)
	{
	    hibernateTemplate.update(data);	
	}
	
	
	/*@SuppressWarnings("unchecked")
	public LoginUser getByUser(String username){
		DetachedCriteria detachedCriteria =  DetachedCriteria.forClass(LoginUser.class);
		detachedCriteria.add(Restrictions.eq("username", username));
		//detachedCriteria.add(Restrictions.eq("password", password));
		List<LoginUser> findByCriteria = (List<LoginUser>) hibernateTemplate.findByCriteria(detachedCriteria);
		if(findByCriteria !=null && findByCriteria.size()>0)
		return findByCriteria.get(0);
		else
			return null;
	}*/
	
	
}
